<?php
require_once __DIR__ . '/../config.php';
$pageTitle = 'Dashboard';
$pdo = db();
$students = (int)$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$questions = (int)$pdo->query("SELECT COUNT(*) FROM questions")->fetchColumn();
$exams = (int)$pdo->query("SELECT COUNT(*) FROM exams")->fetchColumn();
$attempts = (int)$pdo->query("SELECT COUNT(*) FROM attempts WHERE status IN ('submitted','expired')")->fetchColumn();
include __DIR__ . '/header.php';
?>
<h1>Admin Dashboard</h1>
<p class="muted">Welcome, <?= e($_SESSION['admin_name']) ?>.</p>
<div class="stats">
<div class="stat"><b><?= $students ?></b><span>Students</span></div>
<div class="stat"><b><?= $questions ?></b><span>Questions</span></div>
<div class="stat"><b><?= $exams ?></b><span>Exams</span></div>
<div class="stat"><b><?= $attempts ?></b><span>Completed Attempts</span></div>
</div>
<div class="quick-grid">
<a class="card action" href="students.php">Manage Students</a>
<a class="card action" href="questions.php">Manage Questions</a>
<a class="card action" href="exams.php">Create / Manage Exams</a>
<a class="card action" href="results.php">View Student Results</a>
</div>
<?php include __DIR__ . '/footer.php'; ?>
