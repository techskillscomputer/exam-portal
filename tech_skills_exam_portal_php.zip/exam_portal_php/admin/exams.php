<?php
require_once __DIR__ . '/../config.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action=$_POST['action'] ?? '';
    if ($action==='create') {
        $title=trim($_POST['title'] ?? '');
        $description=trim($_POST['description'] ?? '');
        $duration=max(1,(int)($_POST['duration_minutes'] ?? 30));
        $selected=array_values(array_unique(array_map('intval',$_POST['questions'] ?? [])));
        try {
            if (!$title || !$selected) throw new RuntimeException('Exam title and at least one question are required.');
            $pdo->beginTransaction();
            $marks=(int)$pdo->query("SELECT COALESCE(SUM(marks),0) FROM questions WHERE id IN (".implode(',',array_fill(0,count($selected),'?')).")")->execute($selected);
            $stmt=$pdo->prepare("SELECT COALESCE(SUM(marks),0) FROM questions WHERE id IN (".implode(',',array_fill(0,count($selected),'?')).")");
            $stmt->execute($selected);
            $total=(int)$stmt->fetchColumn();
            $stmt=$pdo->prepare("INSERT INTO exams(title,description,duration_minutes,total_marks) VALUES(?,?,?,?)");
            $stmt->execute([$title,$description,$duration,$total]);
            $examId=(int)$pdo->lastInsertId();
            $stmt=$pdo->prepare("INSERT INTO exam_questions(exam_id,question_id,question_order) VALUES(?,?,?)");
            foreach($selected as $i=>$qid) $stmt->execute([$examId,$qid,$i+1]);
            $pdo->commit();
            flash('success','Exam created as Draft.');
        } catch(Throwable $e) {
            if($pdo->inTransaction()) $pdo->rollBack();
            flash('error',$e->getMessage());
        }
        redirect('exams.php');
    }
    if($action==='status') {
        $id=(int)$_POST['id']; $status=$_POST['status'];
        if(in_array($status,['draft','published','closed'],true)) $pdo->prepare("UPDATE exams SET status=? WHERE id=?")->execute([$status,$id]);
        flash('success','Exam status updated.');
        redirect('exams.php');
    }
    if($action==='delete') {
        $id=(int)$_POST['id'];
        $pdo->prepare("DELETE FROM exams WHERE id=?")->execute([$id]);
        flash('success','Exam deleted.');
        redirect('exams.php');
    }
}

$questions=$pdo->query("SELECT id,question_text,marks FROM questions ORDER BY id DESC")->fetchAll();
$exams=$pdo->query("SELECT e.*, COUNT(eq.question_id) qcount FROM exams e LEFT JOIN exam_questions eq ON eq.exam_id=e.id GROUP BY e.id ORDER BY e.id DESC")->fetchAll();
$pageTitle='Exams';
include __DIR__ . '/header.php';
?>
<h1>Create Exam</h1>
<div class="card">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="create">
<div class="form-grid">
<div><label>Exam Title</label><input name="title" required></div>
<div><label>Duration (minutes)</label><input type="number" name="duration_minutes" min="1" value="30" required></div>
<div class="full-row"><label>Description</label><textarea name="description"></textarea></div>
</div>
<h3>Select Questions</h3>
<div class="question-picker">
<?php foreach($questions as $q): ?><label class="pick"><input type="checkbox" name="questions[]" value="<?= (int)$q['id'] ?>"> <span><b>#<?= (int)$q['id'] ?></b> <?= e($q['question_text']) ?> <small>(<?= (int)$q['marks'] ?> mark)</small></span></label><?php endforeach; ?>
</div>
<button class="btn primary">Create Exam</button>
</form></div>

<div class="card"><h2>Exams</h2><div class="table-wrap"><table><tr><th>Title</th><th>Questions</th><th>Marks</th><th>Time</th><th>Status</th><th>Action</th></tr>
<?php foreach($exams as $e): ?><tr><td><?= e($e['title']) ?></td><td><?= (int)$e['qcount'] ?></td><td><?= (int)$e['total_marks'] ?></td><td><?= (int)$e['duration_minutes'] ?> min</td><td><span class="badge <?= e($e['status']) ?>"><?= e($e['status']) ?></span></td>
<td>
<form method="post" class="inline"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="status"><input type="hidden" name="id" value="<?= (int)$e['id'] ?>">
<select name="status"><option value="draft" <?= $e['status']==='draft'?'selected':'' ?>>Draft</option><option value="published" <?= $e['status']==='published'?'selected':'' ?>>Published</option><option value="closed" <?= $e['status']==='closed'?'selected':'' ?>>Closed</option></select><button class="btn small">Save</button></form>
<form method="post" class="inline" onsubmit="return confirm('Delete exam?')"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$e['id'] ?>"><button class="btn danger small">Delete</button></form>
</td></tr><?php endforeach; ?></table></div></div>
<?php include __DIR__ . '/footer.php'; ?>
