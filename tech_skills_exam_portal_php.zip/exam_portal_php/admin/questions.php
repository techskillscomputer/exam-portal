<?php
require_once __DIR__ . '/../config.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $q = trim($_POST['question_text'] ?? '');
        $a = trim($_POST['option_a'] ?? '');
        $b = trim($_POST['option_b'] ?? '');
        $c = trim($_POST['option_c'] ?? '');
        $d = trim($_POST['option_d'] ?? '');
        $correct = $_POST['correct_option'] ?? '';
        $marks = max(1, (int)($_POST['marks'] ?? 1));
        if (!$q || !$a || !$b || !$c || !$d || !in_array($correct,['A','B','C','D'],true)) {
            flash('error','Please fill all question fields.');
        } else {
            $stmt=$pdo->prepare("INSERT INTO questions (question_text,option_a,option_b,option_c,option_d,correct_option,marks) VALUES (?,?,?,?,?,?,?)");
            $stmt->execute([$q,$a,$b,$c,$d,$correct,$marks]);
            flash('success','Question added.');
        }
        redirect('questions.php');
    }
    if ($action === 'delete') {
        $id=(int)$_POST['id'];
        $pdo->prepare("DELETE FROM questions WHERE id=?")->execute([$id]);
        flash('success','Question deleted.');
        redirect('questions.php');
    }
}
$rows=$pdo->query("SELECT * FROM questions ORDER BY id DESC")->fetchAll();
$pageTitle='Questions';
include __DIR__ . '/header.php';
?>
<h1>Question Bank</h1>
<div class="card">
<h2>Add Question</h2>
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="add">
<label>Question</label><textarea name="question_text" required></textarea>
<div class="form-grid">
<div><label>Option A</label><input name="option_a" required></div>
<div><label>Option B</label><input name="option_b" required></div>
<div><label>Option C</label><input name="option_c" required></div>
<div><label>Option D</label><input name="option_d" required></div>
<div><label>Correct Option</label><select name="correct_option" required><option value="">Select</option><option>A</option><option>B</option><option>C</option><option>D</option></select></div>
<div><label>Marks</label><input type="number" name="marks" min="1" value="1" required></div>
</div>
<button class="btn primary">Add Question</button>
</form></div>

<div class="card"><h2>Question Bank</h2>
<div class="table-wrap"><table><tr><th>#</th><th>Question</th><th>Correct</th><th>Marks</th><th>Action</th></tr>
<?php foreach($rows as $r): ?><tr>
<td><?= (int)$r['id'] ?></td><td><?= e($r['question_text']) ?></td><td><?= e($r['correct_option']) ?></td><td><?= (int)$r['marks'] ?></td>
<td><form method="post" onsubmit="return confirm('Delete this question?')"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn danger small">Delete</button></form></td>
</tr><?php endforeach; ?></table></div></div>
<?php include __DIR__ . '/footer.php'; ?>
