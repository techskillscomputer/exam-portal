<?php
require_once __DIR__ . '/../config.php';
$pdo=db();
$rows=$pdo->query("SELECT a.*, s.student_code,s.name student_name,e.title exam_title,e.total_marks FROM attempts a JOIN students s ON s.id=a.student_id JOIN exams e ON e.id=a.exam_id WHERE a.status IN ('submitted','expired') ORDER BY a.submitted_at DESC")->fetchAll();
$pageTitle='Results';
include __DIR__ . '/header.php';
?>
<h1>Student Results</h1>
<div class="card"><div class="table-wrap"><table><tr><th>Student</th><th>Exam</th><th>Score</th><th>Percentage</th><th>Status</th><th>Submitted</th></tr>
<?php foreach($rows as $r): ?><tr><td><?= e($r['student_name']) ?><br><small><?= e($r['student_code']) ?></small></td><td><?= e($r['exam_title']) ?></td><td><?= (int)$r['score'] ?> / <?= (int)$r['total_marks'] ?></td><td><?= e((string)$r['percentage']) ?>%</td><td><?= e($r['status']) ?></td><td><?= e($r['submitted_at']) ?></td></tr><?php endforeach; ?></table></div></div>
<?php include __DIR__ . '/footer.php'; ?>
