<?php
require_once __DIR__ . '/../config.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $code = trim($_POST['student_code'] ?? '');
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '') ?: null;
        $password = $_POST['password'] ?? '';
        try {
            if ($code === '' || $name === '' || strlen($password) < 6) throw new RuntimeException('Student ID/name required and password must be 6+ characters.');
            $stmt = $pdo->prepare("INSERT INTO students (student_code,name,email,password_hash) VALUES (?,?,?,?)");
            $stmt->execute([$code,$name,$email,password_hash($password,PASSWORD_DEFAULT)]);
            flash('success','Student added successfully.');
        } catch (Throwable $e) { flash('error',$e->getCode() === '23000' ? 'Student ID already exists.' : $e->getMessage()); }
        redirect('students.php');
    }

    if ($action === 'toggle') {
        $id = (int)$_POST['id'];
        $pdo->prepare("UPDATE students SET status = IF(status='active','inactive','active') WHERE id=?")->execute([$id]);
        flash('success','Student status updated.');
        redirect('students.php');
    }
}

$rows = $pdo->query("SELECT * FROM students ORDER BY id DESC")->fetchAll();
$pageTitle = 'Students';
include __DIR__ . '/header.php';
?>
<h1>Students</h1>
<div class="card">
<h2>Add Student</h2>
<form method="post" class="form-grid">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="add">
<div><label>Student ID</label><input name="student_code" placeholder="TS001" required></div>
<div><label>Name</label><input name="name" required></div>
<div><label>Email (optional)</label><input type="email" name="email"></div>
<div><label>Password</label><input type="password" name="password" minlength="6" required></div>
<div class="full-row"><button class="btn primary">Add Student</button></div>
</form>
</div>
<div class="card"><h2>Student List</h2>
<div class="table-wrap"><table><tr><th>ID</th><th>Student ID</th><th>Name</th><th>Email</th><th>Status</th><th>Action</th></tr>
<?php foreach ($rows as $r): ?><tr>
<td><?= (int)$r['id'] ?></td><td><?= e($r['student_code']) ?></td><td><?= e($r['name']) ?></td><td><?= e($r['email']) ?></td>
<td><span class="badge <?= e($r['status']) ?>"><?= e($r['status']) ?></span></td>
<td><form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn small"><?= $r['status']==='active'?'Deactivate':'Activate' ?></button></form></td>
</tr><?php endforeach; ?>
</table></div></div>
<?php include __DIR__ . '/footer.php'; ?>
