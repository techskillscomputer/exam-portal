<?php require_admin(); ?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle ?? 'Admin') ?> - <?= e(APP_NAME) ?></title><link rel="stylesheet" href="../assets/style.css"></head>
<body>
<header class="topbar"><div><strong><?= e(APP_NAME) ?></strong><span>Admin Panel</span></div>
<nav><a href="dashboard.php">Dashboard</a><a href="students.php">Students</a><a href="questions.php">Questions</a><a href="exams.php">Exams</a><a href="results.php">Results</a><a href="../logout.php">Logout</a></nav></header>
<main class="container">
<?php if ($m = flash('success')): ?><div class="alert success"><?= e($m) ?></div><?php endif; ?>
<?php if ($m = flash('error')): ?><div class="alert error"><?= e($m) ?></div><?php endif; ?>
