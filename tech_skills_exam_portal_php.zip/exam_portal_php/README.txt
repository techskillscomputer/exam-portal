TECH SKILLS COMPUTER INSTITUTE - EXAM PORTAL
==============================================

TECH STACK
- PHP 8.x
- MySQL / MariaDB
- HTML/CSS/JavaScript
- PDO prepared statements
- PHP sessions
- password_hash/password_verify
- CSRF protection for POST actions

FEATURES
1. Admin Login
2. Add/activate/deactivate students
3. Add MCQ questions with marks and correct answer
4. Create exams by selecting questions
5. Publish/close exams
6. Student Login
7. Server-side attempt timer (expires_at)
8. Automatic marking on server
9. Student results
10. Admin result panel

LOCAL SETUP WITH XAMPP
1. Install XAMPP with Apache + MySQL.
2. Copy the "exam_portal_php" folder to:
   C:\xampp\htdocs\
3. Start Apache and MySQL in XAMPP.
4. Open phpMyAdmin:
   http://localhost/phpmyadmin
5. Import setup.sql.
6. Open:
   http://localhost/exam_portal_php/install.php
7. Create the first admin account.
8. DELETE install.php after successful setup.
9. Open:
   http://localhost/exam_portal_php/

IMPORTANT
- Change DB credentials in config.php if your MySQL setup uses a password.
- For production, use HTTPS.
- Do not leave install.php on a live server.
- Create strong admin/student passwords.
- Back up the database regularly.
- This starter uses one attempt per student per exam (UNIQUE exam_id + student_id).
- To allow retakes, remove that unique constraint and add an attempt policy.

HOSTING
GitHub Pages cannot run this PHP/MySQL system.
Use PHP/MySQL hosting (for example a cPanel host, a VPS, or another PHP-compatible service).
Upload the files, create a MySQL database/user, import setup.sql, update config.php, run install.php once, then delete install.php.

NEXT SECURITY/PRODUCTION IMPROVEMENTS
- HTTPS
- Secure session cookie settings
- Login rate limiting
- Admin password reset
- Audit logs
- Backup/restore
- Per-exam access rules
- Randomized question/option order
- Result export to CSV/PDF
- Student profile management
- Email/SMS notifications
