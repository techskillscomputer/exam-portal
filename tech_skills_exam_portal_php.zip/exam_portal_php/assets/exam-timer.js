(() => {
  const timer = document.getElementById('timer');
  const form = document.getElementById('examForm');
  if (!timer || !form) return;

  const expires = new Date(timer.dataset.expires.replace(' ', 'T')).getTime();

  function update() {
    const remaining = Math.max(0, expires - Date.now());
    const totalSeconds = Math.floor(remaining / 1000);
    const min = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
    const sec = String(totalSeconds % 60).padStart(2, '0');
    timer.textContent = `${min}:${sec}`;

    if (remaining <= 0) {
      form.submit();
    }
  }

  update();
  setInterval(update, 1000);
})();
