<?php
require_once __DIR__ . '/config.php';

if (!empty($_SESSION['admin_id'])) redirect('admin/dashboard.php');
if (!empty($_SESSION['student_id'])) redirect('student/dashboard.php');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e(APP_NAME) ?> - Exam Portal</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="landing">
<div class="landing-card">
    <div class="brand">TS</div>
    <h1><?= e(APP_NAME) ?></h1>
    <p class="muted">Online Examination Portal</p>
    <div class="role-grid">
        <a class="role-card" href="admin/login.php"><strong>Admin</strong><span>Manage students, questions, exams and results</span></a>
        <a class="role-card" href="student/login.php"><strong>Student</strong><span>Login, take exams and view results</span></a>
    </div>
</div>
</body>
</html>
