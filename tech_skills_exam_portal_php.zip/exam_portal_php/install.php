<?php
require_once __DIR__ . '/config.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo = db();

        $adminName = trim($_POST['admin_name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($adminName === '' || $username === '' || strlen($password) < 8) {
            throw new RuntimeException('Enter admin name, username and a password of at least 8 characters.');
        }

        $count = (int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();

        if ($count > 0) {
            throw new RuntimeException('An admin already exists. Delete or rename install.php after setup.');
        }

        $stmt = $pdo->prepare("INSERT INTO admins (name, username, password_hash) VALUES (?, ?, ?)");
        $stmt->execute([$adminName, $username, password_hash($password, PASSWORD_DEFAULT)]);

        $message = 'Installation complete. Delete install.php now, then use the Admin Login.';
    } catch (Throwable $ex) {
        $error = $ex->getMessage();
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Install Exam Portal</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container narrow">
<div class="card">
<h1>Exam Portal Installation</h1>
<p class="muted">First import setup.sql into MySQL/phpMyAdmin, then create your first admin account here.</p>
<?php if ($message): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post">
<label>Admin Name</label>
<input name="admin_name" required>
<label>Username</label>
<input name="username" required>
<label>Password (8+ characters)</label>
<input type="password" name="password" minlength="8" required>
<button class="btn primary" type="submit">Create Admin</button>
</form>
<p class="warning">After successful setup, delete <b>install.php</b> from the server.</p>
</div>
</div>
</body>
</html>
