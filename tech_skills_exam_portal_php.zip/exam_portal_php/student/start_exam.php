<?php
require_once __DIR__ . '/../config.php';
require_student();
$pdo=db();
$studentId=(int)$_SESSION['student_id'];
$examId=(int)($_GET['id'] ?? 0);

$stmt=$pdo->prepare("SELECT * FROM exams WHERE id=? AND status='published'");
$stmt->execute([$examId]);
$exam=$stmt->fetch();
if(!$exam) { flash('error','Exam not available.'); redirect('dashboard.php'); }

$stmt=$pdo->prepare("SELECT * FROM attempts WHERE exam_id=? AND student_id=?");
$stmt->execute([$examId,$studentId]);
$attempt=$stmt->fetch();

if($attempt && $attempt['status']==='submitted') { redirect('results.php'); }

if(!$attempt) {
    $started=time();
    $expires=$started + ((int)$exam['duration_minutes']*60);
    $stmt=$pdo->prepare("INSERT INTO attempts(exam_id,student_id,started_at,expires_at) VALUES(?,?,FROM_UNIXTIME(?),FROM_UNIXTIME(?))");
    $stmt->execute([$examId,$studentId,$started,$expires]);
    $attemptId=(int)$pdo->lastInsertId();
} else {
    $attemptId=(int)$attempt['id'];
    $expires=strtotime($attempt['expires_at']);
    if(time() >= $expires) redirect('submit_exam.php?attempt='.$attemptId.'&auto=1');
}

redirect('exam.php?attempt='.$attemptId);
