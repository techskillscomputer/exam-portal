<?php
require_once __DIR__ . '/../config.php';
require_student();
$pdo=db();
$studentId=(int)$_SESSION['student_id'];
$attemptId=(int)($_GET['attempt'] ?? 0);

$stmt=$pdo->prepare("SELECT a.*,e.title,e.description,e.total_marks FROM attempts a JOIN exams e ON e.id=a.exam_id WHERE a.id=? AND a.student_id=?");
$stmt->execute([$attemptId,$studentId]);
$attempt=$stmt->fetch();
if(!$attempt || $attempt['status']!=='in_progress') redirect('dashboard.php');

if(time() >= strtotime($attempt['expires_at'])) redirect('submit_exam.php?attempt='.$attemptId.'&auto=1');

$stmt=$pdo->prepare("SELECT q.* FROM exam_questions eq JOIN questions q ON q.id=eq.question_id WHERE eq.exam_id=? ORDER BY eq.question_order");
$stmt->execute([$attempt['exam_id']]);
$questions=$stmt->fetchAll();
$pageTitle=$attempt['title'];
include __DIR__ . '/header.php';
?>
<div class="exam-top">
<div><h1><?= e($attempt['title']) ?></h1><p><?= e($attempt['description']) ?></p></div>
<div class="timer" id="timer" data-expires="<?= e($attempt['expires_at']) ?>">--:--</div>
</div>
<form method="post" action="submit_exam.php" id="examForm">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="attempt_id" value="<?= $attemptId ?>">
<?php foreach($questions as $i=>$q): ?>
<div class="card question">
<h3>Q<?= $i+1 ?>. <?= e($q['question_text']) ?> <small>(<?= (int)$q['marks'] ?> mark)</small></h3>
<?php foreach(['A','B','C','D'] as $letter): $field='option_'.strtolower($letter); ?>
<label class="answer"><input type="radio" name="answers[<?= (int)$q['id'] ?>]" value="<?= $letter ?>"> <b><?= $letter ?>.</b> <?= e($q[$field]) ?></label>
<?php endforeach; ?>
</div>
<?php endforeach; ?>
<button class="btn primary large" type="submit" onclick="return confirm('Submit your exam?')">Submit Exam</button>
</form>
<script src="../assets/exam-timer.js"></script>
<?php include __DIR__ . '/footer.php'; ?>
