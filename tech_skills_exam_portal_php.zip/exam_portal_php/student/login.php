<?php
require_once __DIR__ . '/../config.php';
if (!empty($_SESSION['student_id'])) redirect('dashboard.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $code = trim($_POST['student_code'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = db()->prepare("SELECT * FROM students WHERE student_code = ? AND status = 'active'");
    $stmt->execute([$code]);
    $student = $stmt->fetch();
    if ($student && password_verify($password, $student['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['student_id'] = (int)$student['id'];
        $_SESSION['student_name'] = $student['name'];
        redirect('dashboard.php');
    }
    $error = 'Invalid student ID or password.';
}
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Student Login</title><link rel="stylesheet" href="../assets/style.css"></head>
<body class="landing"><div class="login-card">
<div class="brand">TS</div><h1>Student Login</h1><p class="muted"><?= e(APP_NAME) ?></p>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<label>Student ID</label><input name="student_code" required>
<label>Password</label><input type="password" name="password" required>
<button class="btn primary full">Login</button>
</form>
<a class="back-link" href="../index.php">← Back</a>
</div></body></html>
