<?php
require_once __DIR__ . '/../config.php';
$pdo=db();
$studentId=(int)$_SESSION['student_id'];
$stmt=$pdo->prepare("SELECT e.*, COUNT(eq.question_id) qcount,
    EXISTS(SELECT 1 FROM attempts a WHERE a.exam_id=e.id AND a.student_id=? AND a.status IN ('submitted','expired')) completed
    FROM exams e LEFT JOIN exam_questions eq ON eq.exam_id=e.id
    WHERE e.status='published' GROUP BY e.id ORDER BY e.id DESC");
$stmt->execute([$studentId]);
$exams=$stmt->fetchAll();
$pageTitle='Dashboard';
include __DIR__ . '/header.php';
?>
<h1>Welcome, <?= e($_SESSION['student_name']) ?></h1>
<p class="muted">Available examinations</p>
<div class="exam-grid">
<?php foreach($exams as $exam): ?><div class="card exam-card">
<h2><?= e($exam['title']) ?></h2>
<p><?= e($exam['description']) ?></p>
<p><b>Questions:</b> <?= (int)$exam['qcount'] ?> &nbsp; <b>Marks:</b> <?= (int)$exam['total_marks'] ?> &nbsp; <b>Time:</b> <?= (int)$exam['duration_minutes'] ?> min</p>
<?php if($exam['completed']): ?><span class="badge submitted">Already Submitted</span><?php else: ?><a class="btn primary" href="start_exam.php?id=<?= (int)$exam['id'] ?>">Start Exam</a><?php endif; ?>
</div><?php endforeach; ?>
<?php if(!$exams): ?><div class="card"><p>No published exams are available.</p></div><?php endif; ?>
</div>
<?php include __DIR__ . '/footer.php'; ?>
