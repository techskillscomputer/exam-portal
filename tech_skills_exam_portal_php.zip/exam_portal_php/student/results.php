<?php
require_once __DIR__ . '/../config.php';
$pdo=db();
$studentId=(int)$_SESSION['student_id'];
$stmt=$pdo->prepare("SELECT a.*,e.title,e.total_marks FROM attempts a JOIN exams e ON e.id=a.exam_id WHERE a.student_id=? AND a.status IN ('submitted','expired') ORDER BY a.submitted_at DESC");
$stmt->execute([$studentId]);
$rows=$stmt->fetchAll();
$pageTitle='My Results';
include __DIR__ . '/header.php';
?>
<h1>My Results</h1>
<div class="card"><div class="table-wrap"><table><tr><th>Exam</th><th>Score</th><th>Percentage</th><th>Status</th><th>Date</th></tr>
<?php foreach($rows as $r): ?><tr><td><?= e($r['title']) ?></td><td><?= (int)$r['score'] ?> / <?= (int)$r['total_marks'] ?></td><td><?= e((string)$r['percentage']) ?>%</td><td><?= e($r['status']) ?></td><td><?= e($r['submitted_at']) ?></td></tr><?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="5">No results yet.</td></tr><?php endif; ?>
</table></div></div>
<?php include __DIR__ . '/footer.php'; ?>
