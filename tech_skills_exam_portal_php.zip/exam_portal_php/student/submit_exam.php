<?php
require_once __DIR__ . '/../config.php';
require_student();
$pdo=db();
$studentId=(int)$_SESSION['student_id'];

if($_SERVER['REQUEST_METHOD']!=='POST' && !isset($_GET['auto'])) {
    redirect('dashboard.php');
}
if($_SERVER['REQUEST_METHOD']==='POST') check_csrf();

$attemptId=(int)($_POST['attempt_id'] ?? $_GET['attempt'] ?? 0);
$answers=$_POST['answers'] ?? [];

$stmt=$pdo->prepare("SELECT a.*,e.total_marks FROM attempts a JOIN exams e ON e.id=a.exam_id WHERE a.id=? AND a.student_id=?");
$stmt->execute([$attemptId,$studentId]);
$attempt=$stmt->fetch();

if(!$attempt) exit('Invalid attempt.');
if($attempt['status']==='submitted') redirect('results.php');

$stmt=$pdo->prepare("SELECT q.* FROM exam_questions eq JOIN questions q ON q.id=eq.question_id WHERE eq.exam_id=? ORDER BY eq.question_order");
$stmt->execute([$attempt['exam_id']]);
$questions=$stmt->fetchAll();

$expired = time() >= strtotime($attempt['expires_at']);
$score=0;

$pdo->beginTransaction();
try {
    $insert=$pdo->prepare("INSERT INTO attempt_answers(attempt_id,question_id,selected_option,is_correct,marks_awarded) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE selected_option=VALUES(selected_option),is_correct=VALUES(is_correct),marks_awarded=VALUES(marks_awarded)");
    foreach($questions as $q) {
        $selected=$answers[$q['id']] ?? null;
        if(!in_array($selected,['A','B','C','D'],true)) $selected=null;
        $correct=($selected !== null && $selected === $q['correct_option']) ? 1 : 0;
        $marks=$correct ? (int)$q['marks'] : 0;
        $score += $marks;
        $insert->execute([$attemptId,$q['id'],$selected,$correct,$marks]);
    }
    $percentage=$attempt['total_marks'] > 0 ? round(($score/$attempt['total_marks'])*100,2) : 0;
    $status=$expired ? 'expired' : 'submitted';
    $stmt=$pdo->prepare("UPDATE attempts SET submitted_at=NOW(),score=?,percentage=?,status=? WHERE id=?");
    $stmt->execute([$score,$percentage,$status,$attemptId]);
    $pdo->commit();
} catch(Throwable $e) {
    $pdo->rollBack();
    http_response_code(500);
    exit('Could not submit exam.');
}
redirect('results.php');
